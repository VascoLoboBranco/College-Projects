package pt.iul.poo.firefight.objects;

import java.awt.Point;
import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.poo.firefight.main.FireSimulator;

public class Plane extends FireFightObject {
	private FireSimulator f;
	private Point position;
	private String ImageName = "plane";
	int X;
	int Y;
	
	public Plane(Point position, FireSimulator f){
		super(position);
		this.f = f;
		if(f.isFire(position)){
			f.Douse(position);
		}
		X = position.x;
		Y = position.y;
	}
	
	public void move(){
		Point first = new Point(X, Y - 1);
		Point second = new Point (X, Y - 2); 
		if(f.isFire(first)){
			f.Douse(first);
		}
		if(f.isFire(second)){
			f.Douse(second);
		}
		this.Y = second.y;
		super.setPosition(second);
		
	}
	
}
