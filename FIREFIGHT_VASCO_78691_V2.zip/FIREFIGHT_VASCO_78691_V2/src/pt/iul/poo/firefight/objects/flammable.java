package pt.iul.poo.firefight.objects;


public interface flammable {
	
	boolean isOnFire();
	
	int getTime();
	
	
//	void ash();
	

}
