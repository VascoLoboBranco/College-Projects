package pt.iul.poo.firefight.objects;

import java.awt.Point;
import java.util.Random;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.poo.firefight.main.FireSimulator;

public class Fireman extends FireFightObject  {
	FireSimulator f;
	private boolean onBull = false;
	
	public Fireman(Point position, FireSimulator f) {
		super(position);
		this.f = f;
	}

	public int getLayer() {
		return 3;
	}

	public void move(Direction dir) {
		Point current = super.getPosition();
		int newX = (int) (super.getPosition().getX() + dir.asVector().getX());
		int newY = (int) (super.getPosition().getY() + dir.asVector().getY());
		
		Point newPoint = new Point(newX, newY);
		
		if(newPoint.getX() >= 0 && newPoint.getX() < 10 && newPoint.getY() >= 0 && newPoint.getY() < 10 )
		{
			if(f.isFire(newPoint)){
				f.Douse(newPoint);
				super.setPosition(current);
			}
			else{
				if(f.isBull(newPoint)){
					super.setPosition(new Point(20,20));
					this.onBull = true;
				}
				else{
				super.setPosition(newPoint);
				}
			}
			
		}
		ImageMatrixGUI.getInstance().update();
	}
	public boolean isOnBull(){
		return onBull;
	}


	public void offBull(Point p){
		this.onBull = false;
		super.setPosition(new Point(p.x,p.y - 1));
	}
	
//	public boolean getFlam() {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	@Override
//	public double getProb() {
//		// TODO Auto-generated method stub
//		return 0;
//	}

//	public int getTime() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//	
	
	
	
	
}
