package pt.iul.poo.firefight.objects;

import java.awt.Point;

import pt.iul.ista.poo.utils.Direction;
import pt.iul.poo.firefight.main.FireSimulator;

public class bulldozer extends FireFightObject{
	String imageName;
	FireSimulator f;
	
	public bulldozer(Point position, FireSimulator f) {
		super(position);
		this.imageName = "bulldozer_up";
		this.f = f;
		// TODO Auto-generated constructor stub
	}

	public int getLayer(){
		return 4;
	}
	
	public String getName(){
		return imageName;
	}
	
	public void move(Direction dir){
		
		int newX = (int) (super.getPosition().getX() + dir.asVector().getX());
		int newY = (int) (super.getPosition().getY() + dir.asVector().getY());
		if(newX >= 0 && newX < 10 && newY >= 0 && newY < 10 ){
		Point newPoint = new Point(newX, newY);
		f.remover(newPoint);
		super.setPosition(newPoint);
		updateImageName(dir);
		}
		
	}
	
	private void updateImageName(Direction direction) {
		switch (direction) {
		case UP:
			imageName = "bulldozer_up";
			break;
		case DOWN:
			imageName = "bulldozer_down";
			break;
		case LEFT:
			imageName = "bulldozer_left";
			break;
		case RIGHT:
			imageName = "bulldozer_right";
			break;
		}
	}
}
