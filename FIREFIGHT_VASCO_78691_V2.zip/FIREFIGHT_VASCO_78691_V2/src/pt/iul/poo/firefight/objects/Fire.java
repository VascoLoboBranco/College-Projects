package pt.iul.poo.firefight.objects;
import java.awt.Point;
import java.util.ArrayList;

import pt.iul.ista.poo.utils.Direction;
import pt.iul.poo.firefight.main.FireSimulator;

public class Fire extends FireFightObject {
	Point position;
	FireSimulator f;
	public boolean flammable;
	private double prob;
	
	public Fire(Point position,FireSimulator f) {
		super(position);
		this.position = position;
		this.f = f;
		this.flammable = false;
		this.prob = 0;
	}

	public int getLayer() {
		return 2;
	}
	
	


	@Override
	public double getProb() {
		return this.prob;
	}

//	@Override
//	public boolean getFlam() {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	@Override
//	public int getTime() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
	
}