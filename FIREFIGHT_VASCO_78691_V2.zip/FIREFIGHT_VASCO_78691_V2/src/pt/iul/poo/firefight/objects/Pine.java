package pt.iul.poo.firefight.objects;
import java.awt.Point;

import pt.iul.poo.firefight.main.FireSimulator;

public class Pine extends FireFightObject implements flammable {

	FireSimulator f;
	private String imageName = "pine";
	public boolean onFire;
	private double prob;
	private int time;
	
	public Pine(Point point,FireSimulator f) {
		super(point);
		this.f = f;
		this.onFire = false;
		this.prob = 0.05;
		this.time = 10;
	}
	
	public String getName(){
		return imageName;
	}
	
	public double getProb(){
		return this.prob;
	}
	
	public boolean isOnFire(){
		for(Fire fire : f.getFires()){
			if(fire.getPosition().equals(this.getPosition())){
				onFire = true;
			}
		}
		return onFire;
	}

	@Override
	public int getTime() {
		return this.time;
	}
	
	public void burnTime(){
		time--;
		if(time <= 0){
			changeName();
			this.prob = 0;
		}
	}
	
	public void changeName(){
		imageName = "burnt";
		this.onFire = false;
	}

	public void setFire(boolean v){
		this.onFire = v;
	}
	
}
