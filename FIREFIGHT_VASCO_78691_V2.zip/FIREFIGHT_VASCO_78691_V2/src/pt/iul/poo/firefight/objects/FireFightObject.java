package pt.iul.poo.firefight.objects;
import java.awt.Point;

import pt.iul.ista.poo.gui.ImageTile;

public abstract class FireFightObject implements ImageTile{
	private Point position;
	private double prob;
	private int time;
	private boolean onFire;
	private String imageName;
	

	public FireFightObject(Point position) {
		this.position = position;
	}

	@Override
	public String getName() {
		return getClass().getSimpleName().toLowerCase();
	}

	@Override
	public Point getPosition() {
		return this.position;
	}
	
	@Override
	public int getLayer() {
		return 1;
	}

	public double getProb(){
		return this.prob;
	}

	public boolean isOnFire(){
		return this.onFire;
	}
	
	public void burnTime(){
		time--;
		if(time <= 0){
			changeName();
			this.prob = 0;
		}
	}
	
	public void setFire(boolean v){
		this.onFire = v;
	}
	
	protected void setPosition(Point point) {
		position = point;
	}

	public int getTime() {
		return time;
	}

	public void changeName(){
		imageName = "burnt";
		this.onFire = false;
	}

}
