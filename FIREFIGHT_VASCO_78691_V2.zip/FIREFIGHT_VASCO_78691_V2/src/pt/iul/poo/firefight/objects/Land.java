package pt.iul.poo.firefight.objects;

import java.awt.Point;

import pt.iul.poo.firefight.main.FireSimulator;

public class Land extends FireFightObject {
	private boolean onFire;
	
	public Land(Point position) {
		super(position);
		this.onFire = false;
		// TODO Auto-generated constructor stub
	}

//	@Override
//	public boolean getFlam() {
//		// TODO Auto-generated method stub
//		return false;
//	}

	@Override
	public double getProb() {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
//	public int getTime() {
//		// TODO Auto-generated method stub
//		return 0;
//	}

}
