package pt.iul.poo.firefight.main;

import java.io.FileNotFoundException;

import pt.iul.ista.poo.gui.ImageMatrixGUI;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		FireSimulator f = new FireSimulator();
		ImageMatrixGUI.getInstance().addObserver(f);
		ImageMatrixGUI.getInstance().update();
		ImageMatrixGUI.getInstance().go();
	}

}
