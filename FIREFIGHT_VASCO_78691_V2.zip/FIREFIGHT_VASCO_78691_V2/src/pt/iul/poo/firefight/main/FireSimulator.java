package pt.iul.poo.firefight.main;

import java.awt.Point;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;
import java.util.Scanner;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.gui.ImageTile;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.poo.firefight.objects.Eucaliptus;
import pt.iul.poo.firefight.objects.Fire;
import pt.iul.poo.firefight.objects.FireFightObject;
import pt.iul.poo.firefight.objects.Fireman;
import pt.iul.poo.firefight.objects.Grass;
import pt.iul.poo.firefight.objects.Land;
import pt.iul.poo.firefight.objects.Pine;
import pt.iul.poo.firefight.objects.Plane;
import pt.iul.poo.firefight.objects.bulldozer;

/*@author Vasco Branco 78691 */

public class FireSimulator implements Observer {
	private Fire fire;
	private Fireman fireman;
	private Plane plane;
	private bulldozer bull;
	private ArrayList<Fire> fires = new ArrayList<>();
	private ArrayList<FireFightObject> mapa = new ArrayList<>();
	private ArrayList<ImageTile> tiles = new ArrayList<>();
	private boolean isPlane = false;

	public FireSimulator() {
		mapBuild();
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		int key = (int) arg1;
		
		/*V� se o Fireman est� no bulldozer. Se sim, ent�o este sai.*/
		
		if (key == KeyEvent.VK_ENTER) {
			if (fireman.isOnBull()) {
				fireman.offBull(bull.getPosition());
			}
			
		} else {
			
			/*Primeiro v� se j� h� um aviao no mapa. Se n�o houver, ent�o chama o avi�o*/
			
			if (key == KeyEvent.VK_A) {
				if (!isPlane) {
					Aviao();
				}
			} else {
				Direction dir = Direction.directionFor(key);
				
				/*V� se o fireman est� no bulldozer, se estiver, os inputs de direcao sao lidos para o move na classe bulldozer*/
				
				if (fireman.isOnBull()) {
					bull.move(dir);
				} else {
					
					/*Sen�o estiver no bulldozer, ent�o s� o fireman anda*/
					
					fireman.move(dir);
				}
				Spread();
				burn();
				if (isPlane) {
					plane.move();
				}
			}
		}
		ImageMatrixGUI.getInstance().update();
	}

	private void mapBuild() {

		Point FiremanPos = null;

		/*Leitura do ficheiro e cria��o do mapa*/
		
		try (Scanner scan = new Scanner(new File("levels\\landscape.txt"))) {
			for (int y = 0; y < 10; y++) {
				if (scan.hasNextLine()) {
					char[] line = scan.nextLine().toCharArray();
					for (int x = 0; x < line.length; x++) {
						switch (Character.toString(line[x])) {
						case "p":
							mapa.add(new Pine(new Point(x, y), this));
							break;
						case ".":
							mapa.add(new Land(new Point(x, y)));
							break;
						case "e":
							mapa.add(new Eucaliptus(new Point(x, y), this));
							break;
						case "_":
							mapa.add(new Grass(new Point(x, y), this));
							break;
						case "f":
							mapa.add(new Land(new Point(x, y)));
							FiremanPos = new Point(x, y);
							break;
						case "b":
							mapa.add(new Eucaliptus(new Point(x, y), this));
							fires.add(new Fire(new Point(x, y), this));
							break;
						case "u":
							mapa.add(new Land(new Point(x, y)));
							bull = new bulldozer(new Point(x, y), this);

						}
					}
				}
			}
			this.fireman = new Fireman(FiremanPos, this);
			this.mapa.add(fireman);
			this.mapa.add(bull);
			scan.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Level not found");
		}
		tiles.addAll(mapa);
		tiles.addAll(fires);
		ImageMatrixGUI.getInstance().addImages(tiles);
		ImageMatrixGUI.getInstance().update();
	}

	/*Fun��o que � utilizada para o espalhar dos fogos. Devolve os objectos que estao "ao p�" de cada fogo*/
	
	public ArrayList<FireFightObject> getNeighbors() {
		ArrayList<Point> Neighbors = new ArrayList<>();
		for (FireFightObject obj : fires) {
			int X = obj.getPosition().x;
			int Y = obj.getPosition().y;
			for (int i = 0; i != 4; i++) {
				Point neighbor = null;
				int newX = 0;
				int newY = 0;
				switch (i) {
				case 0:
					newX = X - 1;
					if (newX >= 0) {
						neighbor = new Point(newX, Y);
						Neighbors.add(neighbor);
					}
					break;
				case 1:
					newY = Y - 1;
					if (newY >= 0) {
						neighbor = new Point(X, newY);
						Neighbors.add(neighbor);
					}
					break;
				case 2:
					newX = X + 1;
					if (newX <= 10) {
						neighbor = new Point(newX, Y);
						Neighbors.add(neighbor);
					}
					break;
				case 3:
					newY = Y + 1;
					if (newY <= 10) {
						neighbor = new Point(X, newY);
						Neighbors.add(neighbor);
					}
					break;
				}
			}
		}
		ArrayList<FireFightObject> imgs = new ArrayList<>();
		for (FireFightObject obj : mapa) {
			for (Point p : Neighbors) {
				if (obj.getPosition().equals(p)) {
					imgs.add(obj);
				}
			}
		}
		return imgs;
	}

	/*Fun��o que espalha os fogos. Com o getNeighbors(), faz um teste de aleatoriedade e vai buscar as probabilidas de cada objecto vizinho*/
	
	public void Spread() {
		ArrayList<FireFightObject> imgs = getNeighbors();
		double fireInTheHole = Math.random();
		for (FireFightObject obj : imgs) {
			if (obj.getProb() > fireInTheHole) {
				this.fire = new Fire(obj.getPosition(), this);
				this.fires.add(fire);
				tiles.add(fire);
				ImageMatrixGUI.getInstance().addImage(fire);
				ImageMatrixGUI.getInstance().update();
			}
		}
	}

	/*Devolve os fogos que h� no mapa*/
	
	public ArrayList<Fire> getFires() {
		return this.fires;
	}

	/*Devolve o mapa*/
	
	public ArrayList<FireFightObject> getMap() {
		return this.mapa;
	}

	/*Verifica se o ponto dado � o ponto onde est� o bulldozer*/
	
	public boolean isBull(Point p) {
		return p.equals(bull.getPosition());
	}

	/*Verifica se o ponto dado � um fogo*/
	
	public boolean isFire(Point p) {
		boolean check = false;
		for (FireFightObject obj : fires) {
			if (obj.getPosition().equals(p)) {
				check = true;
			}
		}
		return check;
	}

	/*Fun��o que dado um ponto, se este for Fogo, ent�o o apaga*/
	
	public void Douse(Point p) {
		Iterator<Fire> it = fires.iterator();
		while (it.hasNext()) {
			FireFightObject aux = it.next();
			if (aux.getPosition().equals(p)) {
				for (FireFightObject obj : mapa) {
					if (obj.getPosition().equals(aux.getPosition())) {
						obj.setFire(false);
					}
				}
				it.remove();
				ImageMatrixGUI.getInstance().removeImage(aux);
				ImageMatrixGUI.getInstance().update();
			}
		}
	}

	/*Fun�ao que, em conjunto com a fun��o burntime() das classes abstractas, muda o objecto em chamas para um queimado*/
	
	public void burn() {
		List<FireFightObject> lista = new ArrayList<>();
		for (FireFightObject obj : mapa) {
			if (obj.isOnFire()) {
				lista.add(obj);
			}
		}
		Iterator<FireFightObject> it = lista.iterator();
		while (it.hasNext()) {
			FireFightObject a = it.next();
			a.burnTime();
			if (a.getTime() <= 0) {
				Douse(a.getPosition());
			}
		}
	}

	/*Fun��o utilizada no bulldozer para limpar caminho*/
	
	public void remover(Point p) {
		Iterator<FireFightObject> list = mapa.iterator();
		Iterator<Fire> listFire = fires.iterator();
		while (list.hasNext()) {
			FireFightObject aux = list.next();
			if (aux.getPosition().equals(p)) {
				list.remove();
				ImageMatrixGUI.getInstance().removeImage(aux);
			}
		}
		while (listFire.hasNext()) {
			Fire aux = listFire.next();
			if (aux.getPosition().equals(p)) {
				listFire.remove();
				ImageMatrixGUI.getInstance().removeImage(aux);
			}
		}
		Land aux = new Land(p);
		mapa.add(aux);
		ImageMatrixGUI.getInstance().addImage(aux);
		ImageMatrixGUI.getInstance().update();

	}

	/*Fun��o que v� qual a coluna com mais fogos e chama o aviao para la*/
	
	private void Aviao() {
		int somatorio = 0;
		int somatorioMAX = 0;
		int coluna = 0;
		for (int x = 0; x != 10; x++) {
			somatorio = 0;
			for (FireFightObject obj : mapa) {
				if (obj.isOnFire() && obj.getPosition().getX() == x) {
					somatorio++;
				}
			}
			if (somatorio > somatorioMAX) {
				somatorioMAX = somatorio;
				coluna = x;
			}
		}
		this.plane = new Plane(new Point(coluna, 9), this);
		mapa.add(plane);
		this.isPlane = true;
		ImageMatrixGUI.getInstance().addImage(plane);
		ImageMatrixGUI.getInstance().update();
	}

}
