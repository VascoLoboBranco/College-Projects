import static org.junit.Assert.*;

import org.junit.Test;

public class JUnit_FireSimulator {

	@Test
	public void testFireSimulator() {
		fail("Not yet implemented");
	}

	@Test
	public void testSpread() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetFires() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMap() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsBull() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsFire() {
		fail("Not yet implemented");
	}

	@Test
	public void testDouse() {
		fail("Not yet implemented");
	}

	@Test
	public void testBurn() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemover() {
		fail("Not yet implemented");
	}

}
