package interfaces;

import java.io.IOException;
import java.io.Serializable;
import java.nio.file.FileSystemException;
import java.util.ArrayList;

public interface PCDDirectory extends Serializable{
	
	public abstract boolean fileExists(String name) throws IOException;
	
	public abstract void newFile(String name, ArrayList<String> content) throws FileSystemException, IOException;
	
	public abstract void delete(String name) throws FileSystemException, IOException;
	
	public abstract ArrayList<String> getDirectoryListing() throws FileSystemException, IOException;
	
	public abstract String[] getFile(String name) throws FileSystemException, IOException;
}
