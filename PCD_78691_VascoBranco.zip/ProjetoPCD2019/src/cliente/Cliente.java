package cliente;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import concorrencia.Mensagem;
import concorrencia.ThreadPool;
import janelas.ClienteWindow;
import janelas.MultiJanela;
import janelas.TamanhoJanela;

public class Cliente {
	
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private Socket socket;
	private ClienteWindow window;
	private ThreadPool threadPool = new ThreadPool(10);
	private String endereco = "127.0.0.1";
	private int PORTO_DO_SERVIDOR = 8080;
	public String randomID;
	private Mensagem mensagem;
	private Mensagem nome;
	private Mensagem length;
	private Mensagem mensagemID;
	private Mensagem line;
	private Mensagem nomeFicheiro;

	public static void main(String[] args) throws IOException {
		Cliente cliente = new Cliente();
		if(args.length > 0 && args[0] != null){
			cliente.endereco = args[0];
		}
		if(args.length > 1 && args[1] != null){
			cliente.PORTO_DO_SERVIDOR = Integer.parseInt(args[1]);
		}
		cliente.go();
	}
	
	
	private void go(){
		randomID = (int)(Math.random()*1000000000) + "";
		window = new ClienteWindow(this);
		
		try {
			connectToServer();
		} catch (IOException e) {
			System.out.println("N�o foi poss�vel estabelecer liga��o ao servidor.");
		}
		
		threadPool.submit(() -> listen());
		sendIDNumber();
		sendMessage("ASK");
	}
	
	
	private void connectToServer() throws IOException {
		socket = new Socket(endereco, PORTO_DO_SERVIDOR);	
		System.out.println("Socket = " + socket);
		in = new ObjectInputStream(socket.getInputStream());
		out = new ObjectOutputStream(socket.getOutputStream());
	}
	
	
	private void listen(){
		ArrayList<String> text = new ArrayList<>();
		ArrayList<String> names = new ArrayList<>();
		while(true){
			try {
				Object o  = (Object) in.readObject();
				mensagem = (Mensagem) o;
				
				if(mensagem.getMessage().equals("SENDING_NAMES")){
					names = (ArrayList<String>) in.readObject();
					showNamesInGUI(names);
				}
				
				if(mensagem.getMessage().equals("UPDATE")){
					sendMessage("ASK");
				}
				
				if(mensagem.getMessage().equals("LENGTH")){
					length = (Mensagem) in.readObject();
					TamanhoJanela smallGUI = new TamanhoJanela(this, length.getMessage());
				}
				
				if(mensagem.getMessage().equals("SHOWING_FILE")){
					text.clear();
					nomeFicheiro = (Mensagem) in.readObject();
					mensagemID = (Mensagem) in.readObject();
					text = (ArrayList<String>) in.readObject();
					if(mensagemID.getMessage().equals(randomID)){
						MultiJanela sub = new MultiJanela(this, "Exibindo: " + nomeFicheiro.getMessage(), "Fechar", text);
					}
				}

				if(mensagem.getMessage().equals("SENDING_FILE")){
					text.clear();
					nomeFicheiro = (Mensagem) in.readObject();
					mensagemID = (Mensagem) in.readObject();
					text = (ArrayList<String>) in.readObject();
					if(mensagemID.getMessage().equals(randomID)){
						MultiJanela sub = new MultiJanela(this, "Editando: " + nomeFicheiro.getMessage(), "Gravar", text);
						sub.nome = nomeFicheiro.getMessage();
					}
				}
				
				
				
			} catch (IOException e) {
				System.out.println("Erro na liga��o.");
				System.exit(0);
			} catch (ClassNotFoundException e) {}
		}
	}
	
	
	private void showNamesInGUI(ArrayList<String> names){
		window.updateList(names);
	}
	
	public void sendMessage(String message){
		Mensagem m = new Mensagem(message);
		try {
			out.writeObject(m);
		} catch (IOException e) {}
	}
	
	private void sendIDNumber(){
		String ID = randomID + "";
		sendMessage("IDNumber");
		sendMessage(ID);
	}

	public void releaseFile(String fileName) {
		sendMessage("RELEASING_FILE");
		sendMessage(fileName);
	}

}
