package cliente;

import java.io.IOException;
import java.nio.file.FileSystemException;
import java.util.ArrayList;

import interfaces.PCDFile;

public class RemoteFile implements PCDFile{
	
	private String name;
	private int length;
	private boolean readLocked = false;
	private boolean writeLocked = false;
	private Cliente cliente;
	
	
	public RemoteFile(String name, int length, Cliente cliente){
		this.name = name;
		this.length = length;
		this.cliente = cliente;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public boolean readLock() throws IOException {
		return readLocked;
	}

	@Override
	public boolean writeLock() throws IOException {
		return writeLocked;
	}

	@Override
	public void readUnlock() throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void writeUnlock() throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean exists() throws IOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int length() throws FileSystemException, IOException {
		return length;
	}

	@Override
	public String read() throws FileSystemException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void write(String dataToWrite) throws FileSystemException, IOException {
		System.out.println(dataToWrite);
		String[] lines = dataToWrite.split("\\n");
		int numberOfLines = lines.length;
		cliente.sendMessage("NEW_FILE");
		cliente.sendMessage(name);
		for(int i = 0; i != numberOfLines; i++){
			cliente.sendMessage(lines[i]);
		}
		cliente.sendMessage("FILE_DONE");

		
	}

}
