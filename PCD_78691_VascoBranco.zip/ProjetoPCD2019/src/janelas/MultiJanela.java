package janelas;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.nio.file.FileSystemException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import cliente.Cliente;

public class MultiJanela extends JFrame {

	private JTextArea text = new JTextArea();
	private ClienteWindow window;
	private JButton button;
	private Cliente cliente;
	private String tituloBotao;
	public String novoNome;
	public String nome;
	private String titulo;
	
	
	// Construtor para quando se quer criar um documento
	public MultiJanela(Cliente cliente, String titulo, String button){	
		tituloBotao = button;
		this.cliente = cliente;
		this.button = new JButton(button);
		setLayout(new GridLayout(2,1));
		setTitle(titulo);
		setSize(400, 100);
		addContent();
		open();
	}
	
	// Construtor para quando se quer exibir ou editar um documento
	public MultiJanela(Cliente cliente, String titulo, String button, ArrayList<String> texto){	//construtor 2
		this.titulo = titulo;
		tituloBotao = button;
		boolean first = true;
		if(button.equals("Fechar")){
			text.setEditable(false);
		}
		text.setText("");
		for(String line: texto){
			if(first){
				text.append(line);
				first = false;
			}
			else{
				text.append("\n");
				text.append(line);
			}
		}
		this.cliente = cliente;
		this.button = new JButton(button);
		setLayout(new GridLayout(2,1));
		setTitle(titulo);	
		addContent();
		open();
		setSize(400, 100);
	}
	
	private void open(){
		setVisible(true);
	}
	
	private void addContent(){
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tituloBotao.equals("Criar")){	//novo
					String texto = text.getText();
					int size = texto.length();
					dispose();
					TituloJanela fileTitle = new TituloJanela(cliente, texto, size);
				}
				
				if(tituloBotao.equals("Fechar")){	//exibir
					String name = titulo.substring(10);
					cliente.releaseFile(name);
					dispose();
				}
				
				if(tituloBotao.equals("Gravar")){	//editar
					String texto = text.getText();
					int size = texto.length();
					dispose();
					cliente.sendMessage("EDIT");
					cliente.sendMessage(nome);
					cliente.sendMessage(texto);
					cliente.sendMessage("RELEASING_FILE");
					cliente.sendMessage(nome);
//					RemoteFile editedFile = new RemoteFile(nome, size, cliente);
//					try {
//						editedFile.write(texto);
//					} catch (FileSystemException e1) {} catch (IOException e1) {}
				}
			}
		});
		
		add(text);
		add(button);
		
	}
}
