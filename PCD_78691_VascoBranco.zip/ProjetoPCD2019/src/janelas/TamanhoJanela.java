package janelas;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import cliente.Cliente;

public class TamanhoJanela extends JFrame {

	private Cliente cliente;
	private JList lista = new JList();
	private String length;
	
	public TamanhoJanela(Cliente cliente, String length){
		this.cliente = cliente;
		this.length = length;
		setLayout(new GridLayout(2,1));
		setTitle("Tamanho");	
		addContent();
		showLength();
		open();
		setSize(400, 100);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	private void open(){
		setVisible(true);
	}
	
	private void addContent(){
		add(lista);
	}
	
	private void showLength(){
		String[] length = {this.length};
		lista.setListData(length);
	}
	
}
