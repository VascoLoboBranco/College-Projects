package janelas;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import cliente.Cliente;
import cliente.RemoteFile;

public class TituloJanela extends JFrame {
	
	private JTextField text = new JTextField();
	private JButton button = new JButton("Gravar");
	private Cliente cliente;
	private String conteudo;
	private int length;
	
	public TituloJanela(Cliente cliente, String conteudo, int length){
		this.cliente = cliente;
		this.conteudo = conteudo;
		this.length = length;
		setLayout(new GridLayout(2,1));
		setTitle("Novo ficheiro");	
		addContent();
		open();
		pack();	
	}
	
	private void open(){
		setVisible(true);
	}
	
	private void addContent(){
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = text.getText();
				dispose();
				RemoteFile newFile = new RemoteFile(fileName, length, cliente);
				try {
					newFile.write(conteudo);
				} catch (IOException e1) {}
			}
		});
		
		add(text);
		add(button);
	}
	
}
