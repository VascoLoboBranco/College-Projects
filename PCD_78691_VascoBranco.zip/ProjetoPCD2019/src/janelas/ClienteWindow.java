package janelas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import cliente.Cliente;

public class ClienteWindow extends JFrame {
	
	private Cliente cliente;
	private JPanel botoes = new JPanel();
	private JList lista = new JList();
	private JButton tamanho = new JButton("Tamanho");
	private JButton exibir = new JButton("Exibir");
	private JButton editar = new JButton("Editar");
	private JButton novo = new JButton("Novo");
	private JButton apagar = new JButton("Apagar");

	public ClienteWindow(Cliente cliente){
		this.cliente = cliente;
		setLayout(new GridLayout(2,1));
		setTitle("Explorador de ficheiros");	
		setSize(500, 500);
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setVisible(true);
		addContent();
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	

	private void addContent(){
		add(lista, BorderLayout.CENTER);
		apagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = (String) lista.getSelectedValue();
				clearList();
				cliente.sendMessage("APAGAR");
				cliente.sendMessage(fileName);
				cliente.sendMessage("ASK");
			}
		});
		
		tamanho.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String fileName = (String) lista.getSelectedValue();
				cliente.sendMessage("LENGTH");
				cliente.sendMessage(fileName);
			}
		});
		
		novo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MultiJanela sub = new MultiJanela(cliente, "Novo Ficheiro", "Criar");
			}
		});
		
		exibir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = (String) lista.getSelectedValue();
				if(fileName == null){
					System.out.println("Deve selecionar um ficheiro.");
				}
				else{
					cliente.sendMessage("SHOW_FILE");
					cliente.sendMessage(fileName);
					cliente.sendMessage(cliente.randomID);					
				}
			}
		});
		
		editar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = (String) lista.getSelectedValue();
				if(fileName == null){					
					System.out.println("Deve selecionar um ficheiro.");
				}
				else{
					cliente.sendMessage("SEND_FILE");
					cliente.sendMessage(fileName);
					cliente.sendMessage(cliente.randomID);
				}
			}
		});
		
		
		botoes.setLayout(new FlowLayout());
		botoes.add(tamanho);
		botoes.add(exibir);
		botoes.add(editar);
		botoes.add(novo);
		botoes.add(apagar);
		
		add(botoes,BorderLayout.PAGE_END);
	}
	
	public void updateList(ArrayList<String> names){
		int i=0;
		String[] data = new String[names.size()];
		for(String name: names){
			data[i] = name;
			i++;
		}
		lista.setListData(data);
	}
	
	private void clearList(){
		String[] clear = {""};
		lista.setListData(clear);
	}
	
}
