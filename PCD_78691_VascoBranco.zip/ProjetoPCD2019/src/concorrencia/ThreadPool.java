package concorrencia;

public class ThreadPool {
	private Worker[] pool;
	private BlockingQueue<Runnable> queue = new BlockingQueue<>();
	
	
	public ThreadPool(int quantidade){
		this.pool = new Worker[quantidade];
		for(int i=0; i!=quantidade; i++){
			pool[i] = new Worker();
			pool[i].start();
		}
	}
	
	
	
	public void submit(Runnable r){
		queue.offer(r);
	}
	
	
	private class Worker extends Thread{
		public void run(){
			while(!isInterrupted()){
				Runnable r = queue.poll();
				if(r != null){
					r.run();					
				}
			}
		}
	}
}
