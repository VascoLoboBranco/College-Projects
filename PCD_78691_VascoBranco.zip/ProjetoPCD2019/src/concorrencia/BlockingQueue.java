package concorrencia;

import java.util.ArrayDeque;
import java.util.Queue;

public class BlockingQueue<T> extends Thread{
	
	private Queue<T> queue;
	private int max;
	private boolean limitada;
	private int currentNumber = -1;
	
	public BlockingQueue(){
		queue = new ArrayDeque<>();
		limitada = false;
	}
	
	public BlockingQueue(int max){
		this.max = max;
		queue = new ArrayDeque<>();
		limitada = true;
	}
	
	public synchronized void offer(T o){
		if(limitada){
			if(currentNumber < max){
				queue.add(o);
				currentNumber++;
				notifyAll();
			}
			else{
				try {
					wait();
				} catch (InterruptedException e) {}
			}
		}
		else{
			queue.add(o);
			notifyAll();
		}
	}
	
	public synchronized T poll(){
		if(size() < 0){
			try {
				wait();
			} catch (InterruptedException e) {}
		}
		else{
			if(limitada) currentNumber--;
			notifyAll();
		}
		return queue.poll();
	}
	
	public int size(){
		return queue.size();
	}
	
	public void clear(){
		queue.clear();
	}
	
}
