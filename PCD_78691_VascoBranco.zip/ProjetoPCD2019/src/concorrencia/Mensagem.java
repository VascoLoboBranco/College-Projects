package concorrencia;

import java.io.Serializable;

public class Mensagem implements Serializable{
	
	private String message;
	
	public Mensagem(String message){
		this.message = message;
	}
	
	public String getMessage(){
		return message;
	}
	
	public void setMessage(String message){
		this.message = message;
	}
}
