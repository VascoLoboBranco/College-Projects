package servidor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import interfaces.PCDDirectory;

public class Servidor implements PCDDirectory{
	
	public static int PORTO = 8080;
	private ArrayList<LocalFile> ficheiros = new ArrayList<>();
	public ArrayList<ClientHandler> clientes = new ArrayList<>();
	private String nome = null;

	public static void main(String[] args) {
		Servidor servidor = new Servidor();
		if(args.length > 0 && args[0] != null){
			servidor.nome = args[0];
		}
		if(args.length > 1 && args[1] != null){
			servidor.PORTO = Integer.parseInt(args[1]);
		}
		servidor.getFilesFromDirectory();
		try {
			servidor.startServing();
		} catch (IOException e) {}
	}
	
	
	
	public void startServing() throws IOException {
		ServerSocket s = new ServerSocket(PORTO);
		System.out.println("� espera de conex�o em socket: " + s);
		try {
			while (true) {
				Socket socket = s.accept();
				ClientHandler cliente = new ClientHandler(socket, this);
				cliente.start();
				clientes.add(cliente);
			}
		} finally {
			s.close();
		}
	}
	
	
	private void getFilesFromDirectory(){
		//Adicionar os ficheiros � lista "ficheiros"
		if(!ficheiros.isEmpty()) 
		{
			ficheiros.clear();
		}
		File[] files;
		if(nome != null){
			files = new File(this.nome).listFiles();
		}
		else{
			files = new File("ficheiros").listFiles();			
		}
		for(File file: files){
			LocalFile local = new LocalFile(file.getName(), (int) file.length(), this, file.getAbsolutePath());
			ficheiros.add(local);
		}
	}


	@Override
	public boolean fileExists(String name) throws IOException {
		for(LocalFile file: ficheiros){
			if(file.getName().equals(name)){
				return true;
			}
		}
			return false;
	}



	@Override
	public void newFile(String name, ArrayList<String> content) throws FileSystemException, IOException {
		File file = null;
		boolean first = true;
		File output = new File("ficheiros/" + name + ".txt");
		PrintWriter aux = new PrintWriter(output);
//		PrintWriter output = new PrintWriter("ficheiros/" + name + ".txt");
//		if(nome != null){
////			file = new File(nome + name);
//		}
//		else{
////			file = new File("/ficheiros/" + name + ".txt");	
//			PrintWriter output = new PrintWriter("ficheiros/" + name + ".txt");
//		}
		for(String line: content){
			if(first){
				aux.append(line);
				first = false;
			}
			else{
				aux.append("\n");
				aux.append(line);
			}
		}
		aux.close();
		LocalFile local = new LocalFile(name,(int) output.length(), this, output.getAbsolutePath());
		ficheiros.add(local);
		getFilesFromDirectory();
		sendMessageToUsers("UPDATE");
	}


	public void editFile(String name, String content) throws IOException 
	{
		LocalFile ficheiroLocal = null;
		if(fileExists(name)){
			for(LocalFile ficheiro: ficheiros){
				if(ficheiro.getName().equals(name)){
					ficheiroLocal = ficheiro;		// procurar o ficheiro
				}
			}
			ficheiroLocal.write(content);
			ficheiroLocal.setReadLock(false);
			
		}
	}
	

	@Override
	public void delete(String name) throws FileSystemException, IOException {
		LocalFile ficheiroLocal = null;
		File[] files;
		if(fileExists(name)){
			for(LocalFile ficheiro: ficheiros){
				if(ficheiro.getName().equals(name)){
					ficheiroLocal = ficheiro;		// procurar o ficheiro
				}
			}
			if(ficheiroLocal != null){
				ficheiros.remove(ficheiroLocal);		// apagar da lista "ficheiros"
				if(nome != null){
					files = new File(nome).listFiles();
				}
				else{
					files = new File("ficheiros").listFiles();					
				}
				for(File file: files){
					if(file.getName().equals(ficheiroLocal.getName())){
						file.delete();	// apagar do diretorio						
					}
				}
			}
			
		}
		else{
			System.out.println("N�o existe nenhum ficheiro com o nome: " + name);
		}
		
		sendMessageToUsers("UPDATE");
		
	}



	@Override
	public ArrayList<String> getDirectoryListing() throws FileSystemException, IOException {
		ArrayList<String> fileNames = new ArrayList<>();
		String name;
		for(LocalFile file: ficheiros){
			name = file.getName();
			fileNames.add(name);
		}
		return fileNames;
	}



	@Override
	public String[] getFile(String name) throws FileSystemException, IOException {
		File file = new File("ficheiros/" + name);
		boolean first = true;
		BufferedReader buffer = new BufferedReader(new FileReader(file));
		String texto = "";
		String st; 
		while ((st = buffer.readLine()) != null){
			if(first){
				texto = texto + st;
				first = false;
			}
			else{
				texto = texto + "\n" + st;				
			}
		}
		String[] lines = texto.split("\\n");

		return lines;
	}
	
	public synchronized void showFile(String fileName, String clienteID){
		LocalFile file = null;
		boolean done = false;
		ArrayList<LocalFile> ficheirosLocaisCopy = ficheiros;
		try {
			
			while(!done){
				synchronized(this){
					for(LocalFile f: ficheirosLocaisCopy){
						if(f.getName().equals(fileName)){
							file = f;
						}
					}
					
					if(file.getNumberOfReaders() < 3){
						file.addReader();
						String[] lines = getFile(fileName);
						ArrayList<String> text = new ArrayList<>();
						for(int i=0; i!=lines.length; i++){
							text.add(lines[i]);
						}
						
						showFileToUsers(fileName, clienteID, text);
						done = true;
					}
					
				}
				//espera 1 segundo antes de tentar outra vez 
				wait(1000);				
			}

		} catch (FileSystemException e) {} catch (IOException e) {} catch (InterruptedException e) {}
	}
	
	private void showFileToUsers(String fileName, String clientID, ArrayList<String> text){
		for(ClientHandler cliente: clientes){
			if(cliente.getClientID().equals(clientID)){
				cliente.sendMessage("SHOWING_FILE");
				cliente.sendMessage(fileName);
				cliente.sendMessage(clientID);
				cliente.sendObject(text);
			}
		}
	}
	
	public synchronized void sendFile(String fileName, String clienteID){
		LocalFile file = null;
		ArrayList<LocalFile> ficheirosLocaisCopy = ficheiros;
		
		boolean done = false;
		ArrayList<String> text = new ArrayList<>();
		try {
			while(!done){
				synchronized(this){
					for(LocalFile f: ficheirosLocaisCopy){
						if(f.getName().equals(fileName)){
							file = f;
						}
					}
					if(!file.readLock()){
						file.setReadLock(true);
						String[] lines = getFile(fileName);
						sendMessageToUsers("SENDING_FILE");
						sendMessageToUsers(fileName);
						sendMessageToUsers(clienteID);
						for(int i=0; i!=lines.length; i++){
							text.add(lines[i]);
						}
						sendObjectToUsers(text);
						done = true;
					}
				try {
					//espera um segundo antes de tentar outra vez
					wait(1000);				
				} catch (InterruptedException e) {}
				}
			}
		} catch (FileSystemException e) {} catch (IOException e) {}
	}
	
	
	
	
	private void sendMessageToUsers(String message){
		for(ClientHandler cliente: clientes){
			cliente.sendMessage(message);
		}
	}
	
	private void sendObjectToUsers(Object o){
		for(ClientHandler cliente: clientes){
			cliente.sendObject(o);
		}
	}
	
	
	public int length(String name) throws IOException{
		LocalFile ficheiroLocal = null;
		if(fileExists(name)){
			for(LocalFile ficheiro: ficheiros){
				if(ficheiro.getName().equals(name)){
					ficheiroLocal = ficheiro;
				}
			}
		}
		else{
			System.out.println("N�o existe nenhum ficheiro com o nome: " + name);
		}
			return ficheiroLocal.length();
	}



	public void releaseFile(String fileName) {
		for(LocalFile ficheiro: ficheiros){
			if(ficheiro.getName().equals(fileName)){
				ficheiro.subtractReader();
			}
		}
	}


	
	
	
	
	
}
