package servidor;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.FileSystemException;

import interfaces.PCDFile;

public class LocalFile implements PCDFile{
	
	private String name;
	private int length;
	private boolean readLocked = false;
	private boolean writeLocked = false;
	private Servidor servidor;
	private String fullPath;
	private int numberOfReaders = 0;
	
	
	public LocalFile(String name, int length, Servidor servidor, String fullPath){
		this.name = name;
		this.length = length;
		this.servidor = servidor;
		this.fullPath = fullPath;
	}

	

	@Override
	public String getName() {
		return name;
	}

	@Override
	public boolean readLock() throws IOException {
		return readLocked;
	}

	@Override
	public boolean writeLock() throws IOException {
		return writeLocked;
	}

	@Override
	public void readUnlock() throws IOException {
		
		
	}

	@Override
	public void writeUnlock() throws IOException {
		
		
	}

	@Override
	public boolean exists() throws IOException {
		
		return false;
	}

	@Override
	public int length() throws FileSystemException, IOException {
		return length;
	}

	@Override
	public String read() throws FileSystemException, IOException {
		return new String(read(0, length()));
	}

	@Override
	public void write(String dataToWrite) throws FileSystemException, IOException {
		write(dataToWrite.getBytes(), 0);
	}
	
	
	public byte[] read(int offset, int length) throws FileSystemException {
		ByteBuffer buffer = null;
		RandomAccessFile aFile = null;
		try {
			aFile = new RandomAccessFile(getFullPath(),  "r");
			FileChannel channel = aFile.getChannel();
			
			if(offset > aFile.length()){
				return null;
			}
			
			if(offset + length > aFile.length()){
				length = (int) aFile.length() - offset;
			}
			channel.position(offset);
			buffer = ByteBuffer.allocate(length);
			channel.read(buffer);
			
		} catch (IOException e){
			throw new FileSystemException(e.getMessage());
		} finally{
			if(aFile != null){
				try{
					aFile.close();
				} catch (IOException e){}
			}
		}
		return buffer.array();
	}
	
	public void write(byte[] dataToWrite, int offset) throws FileSystemException{
		RandomAccessFile aFile = null;
		try{
			aFile = new RandomAccessFile(getFullPath(),  "rw");
			FileChannel channel = aFile.getChannel();
			if(offset > aFile.length()){
				offset = (int) aFile.length();
			}
			
			ByteBuffer buf = ByteBuffer.wrap(dataToWrite);
			channel.position(offset);
			
			while(buf.hasRemaining()){
				channel.write(buf);
			}
		} catch(IOException e){
			throw new FileSystemException(e.getMessage());
		} finally {
			if(aFile != null){
				try{
					aFile.close();
				} catch(IOException e){}
			}
		}
	}
	
	private String getFullPath(){
		return fullPath;
	}
	
	public void setReadLock(boolean s){
		readLocked = s;
	}
	
	public int getNumberOfReaders(){
		return numberOfReaders;
	}
	
	public void addReader(){
		numberOfReaders++;
	}
	
	public void subtractReader(){
		numberOfReaders--;
	}
}
