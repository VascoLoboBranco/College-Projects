package servidor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import concorrencia.Mensagem;
import concorrencia.ThreadPool;

public class ClientHandler extends Thread{

	private Socket socket;
	
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private Servidor servidor;
	private ThreadPool threadPool = new ThreadPool(10);
	private String clienteID;
	ArrayList<String> ficheiros = new ArrayList<>();
	private Mensagem mensagem;
	private Mensagem nome;
	private Mensagem length;
	private Mensagem IDMensagem;
	private Mensagem line;
	private Mensagem ficheiroNome;

	public ClientHandler(Socket socket, Servidor server) {
		this.servidor = server;
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			doConnections(socket);
			process();
		} catch (IOException e) {}
		catch (ClassNotFoundException e) {} 
		finally {
			try {
				socket.close();
			} catch (IOException e) {}
		}

	}

	private void doConnections(Socket socket) throws IOException {
		out = new ObjectOutputStream(socket.getOutputStream());
		in = new ObjectInputStream(socket.getInputStream());
	}

	private void process() throws IOException, ClassNotFoundException {
		String length;
		ArrayList<String> lines;
		while (true) {
			mensagem = (Mensagem) in.readObject();
			if(mensagem.getMessage().equals("IDNumber")){
				mensagem = (Mensagem) in.readObject();
				clienteID = mensagem.getMessage();
			}
			if(mensagem.getMessage().equals("ASK")){
				showFiles();
			}
			if(mensagem.getMessage().equals("APAGAR")){
				ficheiroNome = (Mensagem) in.readObject();
				servidor.delete(ficheiroNome.getMessage());
			}
			if(mensagem.getMessage().equals("LENGTH")){
				ficheiroNome = (Mensagem) in.readObject();
				length = "" + servidor.length(ficheiroNome.getMessage());
				sendMessage("LENGTH");
				sendMessage(length);
			}
			if(mensagem.getMessage().equals("NEW_FILE")){
				lines = new ArrayList<>();
				ficheiroNome = (Mensagem) in.readObject();
				Mensagem content = (Mensagem) in.readObject();
				while(!content.getMessage().equals("FILE_DONE")){
					lines.add(content.getMessage());
					content = (Mensagem) in.readObject();
				}
				servidor.newFile(ficheiroNome.getMessage(), lines);
			}
			if(mensagem.getMessage().equals("SHOW_FILE")){
				ficheiroNome = (Mensagem) in.readObject();
				IDMensagem = (Mensagem) in.readObject();
				threadPool.submit(() -> servidor.showFile(ficheiroNome.getMessage(), IDMensagem.getMessage()));
			}
			
			if(mensagem.getMessage().equals("SEND_FILE")){
				ficheiroNome = (Mensagem) in.readObject();
				IDMensagem = (Mensagem) in.readObject();
				threadPool.submit(() -> servidor.sendFile(ficheiroNome.getMessage(), IDMensagem.getMessage()));
			}
			
			if(mensagem.getMessage().equals("RELEASING_FILE")){
				ficheiroNome = (Mensagem) in.readObject();
				servidor.releaseFile(ficheiroNome.getMessage());
			}
			
			if(mensagem.getMessage().equals("EDIT")) {
				ficheiroNome = (Mensagem) in.readObject();
				Mensagem aux = (Mensagem) in.readObject();
				servidor.editFile(ficheiroNome.getMessage(), aux.getMessage());
			}
			
		}
	}
	
	
	private void showFiles() throws IOException{
		Mensagem m = new Mensagem("SENDING_NAMES");
		ficheiros.clear();
		try {
			ficheiros = servidor.getDirectoryListing();
		} catch (IOException e) {}
		out.writeObject(m);
		out.writeObject(ficheiros);
	}
	
	public void sendMessage(String s){
		Mensagem m = new Mensagem(s);
		try {
			out.writeObject(m);
		} catch (IOException e) {}
	}
	
	public void sendObject(Object o){
		try {
			out.writeObject(o);
		} catch (IOException e) {}
	}
	
	public String getClientID(){
		return clienteID;
	}
	
}
